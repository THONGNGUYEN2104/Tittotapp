TikAutoTap - mo thu muc nay bang Android Studio (Open), doi Gradle sync, bam Run.
