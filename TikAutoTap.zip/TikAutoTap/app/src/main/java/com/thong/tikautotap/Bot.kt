package com.thong.tikautotap

/** Trạng thái dùng chung giữa các thành phần. */
object Bot {
    @Volatile var running = false        // đang auto chơi hay không
    @Volatile var captureActive = false  // đã có quyền quay màn hình và đang chạy
    @Volatile var debug = false          // lưu ảnh debug
    @Volatile var taps = 0               // số lần chạm
    @Volatile var skipped = 0            // số lần tránh bom/đầu lâu
}
