package com.thong.tikautotap

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.Process
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.WindowManager
import java.io.File
import java.io.FileOutputStream

/** Quay màn hình ~60fps ở độ phân giải thấp, nhận diện và ra lệnh chạm. */
class CaptureService : Service() {

    companion object {
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        private const val CHANNEL_ID = "tikautotap"
        private const val NOTI_ID = 1

        const val MIN_FRAMES = 2        // vật phải xuất hiện >= 2 khung liên tiếp mới chạm
        const val COOLDOWN_MS = 250L    // chống chạm lặp cùng một lỗ
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var stopping = false

    private var realW = 1080
    private var realH = 2340
    private lateinit var detector: Detector

    private val seen = IntArray(9)
    private val lastTap = LongArray(9)
    private var busyUntil = 0L
    private var lastDebug = 0L
    private var debugCount = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        startAsForeground()

        val code = intent.getIntExtra(EXTRA_CODE, 0)
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(EXTRA_DATA)
        }
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            startCapture(code, data)
        } catch (e: Exception) {
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "TikAutoTap", NotificationManager.IMPORTANCE_LOW)
        )
        val noti: Notification = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("TikAutoTap đang chạy")
            .setContentText("Dùng nút nổi trên màn hình để bắt đầu / dừng")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTI_ID, noti, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTI_ID, noti)
        }
    }

    private fun startCapture(code: Int, data: Intent) {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(dm)
        realW = dm.widthPixels
        realH = dm.heightPixels

        var capW = minOf(540, realW)
        capW -= capW % 2
        var capH = (realH.toFloat() * capW / realW).toInt()
        capH -= capH % 2
        detector = Detector(capW, capH)

        val t = HandlerThread("tikautotap-capture", Process.THREAD_PRIORITY_URGENT_DISPLAY)
        t.start()
        thread = t
        val handler = Handler(t.looper)

        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val mp = mpm.getMediaProjection(code, data)
        projection = mp
        mp.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                if (!stopping) stopSelf()
            }
        }, Handler(Looper.getMainLooper()))

        val r = ImageReader.newInstance(capW, capH, PixelFormat.RGBA_8888, 3)
        reader = r
        r.setOnImageAvailableListener({ rd ->
            var img: Image? = null
            try {
                img = rd.acquireLatestImage()
                if (img != null && Bot.running) process(img)
            } catch (_: Exception) {
            } finally {
                try { img?.close() } catch (_: Exception) {}
            }
        }, handler)

        virtualDisplay = mp.createVirtualDisplay(
            "tikautotap", capW, capH, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            r.surface, null, null
        )

        java.util.Arrays.fill(seen, 0)
        java.util.Arrays.fill(lastTap, 0L)
        Bot.running = false
        Bot.taps = 0
        Bot.skipped = 0
        Bot.captureActive = true
        TapService.instance?.showOverlay()
    }

    private fun process(img: Image) {
        val plane = img.planes[0]
        val buf = plane.buffer
        val rowStride = plane.rowStride
        val pixelStride = plane.pixelStride
        val now = SystemClock.uptimeMillis()

        val kinds = IntArray(detector.count)
        val targets = ArrayList<Int>()
        var danger = false

        for (i in 0 until detector.count) {
            val k = detector.classify(buf, rowStride, pixelStride, i)
            kinds[i] = k
            when (k) {
                Detector.TARGET -> {
                    seen[i]++
                    if (seen[i] >= MIN_FRAMES && now - lastTap[i] >= COOLDOWN_MS) targets.add(i)
                }
                Detector.BOMB, Detector.SKULL -> {
                    seen[i] = 0
                    danger = true
                }
                else -> seen[i] = 0
            }
        }

        var tapped = false
        val svc = TapService.instance
        if (svc != null && targets.isNotEmpty() && now >= busyUntil) {
            val s = realW / Detector.REF_W
            val pts = ArrayList<FloatArray>()
            for (i in targets.take(4)) {
                val x = Detector.HOLES[i][0] / Detector.REF_W * realW
                val y = Detector.HOLES[i][1] / Detector.REF_H * realH - Detector.TAP_UP * s
                pts.add(floatArrayOf(x, y))
                lastTap[i] = now
                seen[i] = 0
            }
            val dur = svc.tap(pts)
            busyUntil = now + dur
            Bot.taps += pts.size
            tapped = true
        }
        if (danger) Bot.skipped++

        if (Bot.debug && (tapped || danger) && now - lastDebug > 300 && debugCount < 80) {
            lastDebug = now
            debugCount++
            saveDebug(img, kinds, now)
        }
    }

    private fun saveDebug(img: Image, kinds: IntArray, ts: Long) {
        try {
            val plane = img.planes[0]
            val w = plane.rowStride / plane.pixelStride
            val full = Bitmap.createBitmap(w, img.height, Bitmap.Config.ARGB_8888)
            plane.buffer.rewind()
            full.copyPixelsFromBuffer(plane.buffer)
            val bmp = Bitmap.createBitmap(full, 0, 0, img.width, img.height)
            val c = Canvas(bmp)
            val p = Paint().apply { style = Paint.Style.STROKE; strokeWidth = 3f; textSize = 22f }
            for (i in kinds.indices) {
                p.color = when (kinds[i]) {
                    Detector.TARGET -> Color.GREEN
                    Detector.BOMB -> Color.RED
                    Detector.SKULL -> Color.MAGENTA
                    else -> Color.argb(60, 255, 255, 255)
                }
                c.drawRect(
                    detector.x0[i].toFloat(), detector.y0[i].toFloat(),
                    detector.x1[i].toFloat(), detector.y1[i].toFloat(), p
                )
            }
            val dir = File(getExternalFilesDir(null), "debug")
            dir.mkdirs()
            FileOutputStream(File(dir, "f_$ts.jpg")).use { bmp.compress(Bitmap.CompressFormat.JPEG, 70, it) }
        } catch (_: Exception) {
        }
    }

    override fun onDestroy() {
        stopping = true
        Bot.running = false
        Bot.captureActive = false
        TapService.instance?.hideOverlay()
        try { virtualDisplay?.release() } catch (_: Exception) {}
        try { reader?.setOnImageAvailableListener(null, null) } catch (_: Exception) {}
        try { reader?.close() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        try { thread?.quitSafely() } catch (_: Exception) {}
        virtualDisplay = null
        reader = null
        projection = null
        thread = null
        super.onDestroy()
    }
}
