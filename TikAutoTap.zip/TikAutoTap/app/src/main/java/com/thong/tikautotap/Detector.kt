package com.thong.tikautotap

import java.nio.ByteBuffer

/**
 * Nhận diện vật thể nhô lên từ 9 lỗ bằng màu sắc (không cần ảnh mẫu).
 *
 * - Vùng phía trên mỗi lỗ chỉ có cỏ xanh khi trống.
 * - Có vật thể = có nhiều điểm ảnh "không phải cỏ".
 * - BOM: thân màu xám đen.   - ĐẦU LÂU: trắng + xương xanh nhạt.
 * - Còn lại (avatar, mèo) = TARGET -> chạm.
 */
class Detector(capW: Int, capH: Int) {

    companion object {
        const val EMPTY = 0
        const val TARGET = 1
        const val BOMB = 2
        const val SKULL = 3

        // Toạ độ tâm 9 lỗ đo trên ảnh chuẩn 1080x2340 (px)
        const val REF_W = 1080f
        const val REF_H = 2340f
        val HOLES = arrayOf(
            floatArrayOf(190f, 625f), floatArrayOf(875f, 625f),
            floatArrayOf(530f, 855f),
            floatArrayOf(190f, 1080f), floatArrayOf(875f, 1080f),
            floatArrayOf(530f, 1310f),
            floatArrayOf(190f, 1525f), floatArrayOf(875f, 1525f),
            floatArrayOf(530f, 1755f)
        )

        // Cửa sổ lấy mẫu phía trên lỗ (đơn vị px của ảnh chuẩn 1080 rộng)
        const val HALF_W = 100f
        const val TOP = 205f
        const val BOTTOM = 90f

        // Điểm chạm: cách tâm lỗ lên trên (px chuẩn)
        const val TAP_UP = 95f

        const val PRESENT_MIN = 0.12f
    }

    val count = HOLES.size
    val x0 = IntArray(count)
    val x1 = IntArray(count)
    val y0 = IntArray(count)
    val y1 = IntArray(count)

    init {
        val s = capW / REF_W
        for (i in 0 until count) {
            val cx = HOLES[i][0] / REF_W * capW
            val cy = HOLES[i][1] / REF_H * capH
            x0[i] = (cx - HALF_W * s).toInt().coerceIn(0, capW - 1)
            x1[i] = (cx + HALF_W * s).toInt().coerceIn(1, capW)
            y0[i] = (cy - TOP * s).toInt().coerceIn(0, capH - 1)
            y1[i] = (cy - BOTTOM * s).toInt().coerceIn(1, capH)
        }
    }

    fun classify(buf: ByteBuffer, rowStride: Int, pixelStride: Int, i: Int): Int {
        var total = 0
        var n = 0
        var white = 0
        var blue = 0
        var dark = 0
        var minX = Int.MAX_VALUE
        var maxX = -1
        var minY = Int.MAX_VALUE
        var maxY = -1

        for (y in y0[i] until y1[i]) {
            val rowBase = y * rowStride
            for (x in x0[i] until x1[i]) {
                val idx = rowBase + x * pixelStride
                val r = buf.get(idx).toInt() and 0xFF
                val g = buf.get(idx + 1).toInt() and 0xFF
                val b = buf.get(idx + 2).toInt() and 0xFF
                total++
                // Cỏ / lỗ: xanh lá chiếm ưu thế
                if (g > r + 25 && g > b + 20) continue
                n++
                val mx = maxOf(r, g, b)
                val mn = minOf(r, g, b)
                val spread = mx - mn
                if (mn >= 215 && spread <= 30) white++
                if (b > r + 20 && r >= 150 && b >= g) blue++
                if (mx <= 125 && spread <= 25) dark++
                if (x < minX) minX = x
                if (x > maxX) maxX = x
                if (y < minY) minY = y
                if (y > maxY) maxY = y
            }
        }
        if (total == 0 || n == 0) return EMPTY
        val f = n.toFloat() / total
        if (f < PRESENT_MIN) return EMPTY

        val whiteR = white.toFloat() / n
        val blueR = blue.toFloat() / n
        val darkR = dark.toFloat() / n
        val bbox = ((maxX - minX + 1) * (maxY - minY + 1)).toFloat()
        val fill = if (bbox > 0) n / bbox else 1f

        if (darkR >= 0.40f) return BOMB
        if (whiteR >= 0.30f && blueR >= 0.05f) return SKULL
        if (whiteR >= 0.55f) return SKULL
        if (whiteR >= 0.45f && fill < 0.66f) return SKULL
        return TARGET
    }
}
