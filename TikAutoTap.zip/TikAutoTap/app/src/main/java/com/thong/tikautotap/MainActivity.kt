package com.thong.tikautotap

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val reqCapture = 1001
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        val pad = (20 * d).toInt()

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        fun tv(text: String, size: Float = 15f, bold: Boolean = false) = TextView(this).apply {
            this.text = text
            textSize = size
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, (6 * d).toInt(), 0, (6 * d).toInt())
        }

        col.addView(tv("TikAutoTap", 26f, true))
        status = tv("")
        col.addView(status)

        col.addView(tv("Bước 1: bật Trợ năng (Accessibility) cho TikAutoTap", 14f, true))
        col.addView(Button(this).apply {
            text = "Mở cài đặt Trợ năng"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })

        col.addView(tv("Bước 2: cấp quyền quay màn hình và hiện nút nổi", 14f, true))
        col.addView(Button(this).apply {
            text = "Bắt đầu (cấp quyền quay màn hình)"
            setOnClickListener { startFlow() }
        })
        col.addView(Button(this).apply {
            text = "Dừng hẳn"
            setOnClickListener {
                stopService(Intent(this@MainActivity, CaptureService::class.java))
                refresh()
            }
        })

        col.addView(CheckBox(this).apply {
            text = "Lưu ảnh debug (Android/data/com.thong.tikautotap/files/debug)"
            setOnCheckedChangeListener { _, checked -> Bot.debug = checked }
        })

        col.addView(
            tv(
                "Cách dùng:\n" +
                        "1. Bật Trợ năng → chọn TikAutoTap → Bật.\n" +
                        "2. Bấm 'Bắt đầu', chọn quay TOÀN BỘ MÀN HÌNH (Entire screen) → Bắt đầu ngay.\n" +
                        "3. Mở TikTok, vào game. Khi ván bắt đầu, bấm nút nổi ▶ CHƠI. Bấm lại để dừng.\n" +
                        "4. Kéo nút nổi để dời vị trí, bấm ✕ để tắt hẳn.\n\n" +
                        "Lưu ý: dùng bot có thể vi phạm điều khoản TikTok và không công bằng với người chơi khác.",
                13f
            )
        )

        setContentView(ScrollView(this).apply { addView(col) })
        col.gravity = Gravity.START
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun accessibilityOn(): Boolean {
        if (TapService.instance != null) return true
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?: return false
        val me = ComponentName(this, TapService::class.java).flattenToString()
        return enabled.split(':').any { it.equals(me, ignoreCase = true) }
    }

    private fun refresh() {
        status.text = "Trợ năng: " + (if (accessibilityOn()) "ĐÃ BẬT ✔" else "CHƯA BẬT ✘") +
                "\nQuay màn hình: " + (if (Bot.captureActive) "ĐANG CHẠY ✔" else "chưa chạy")
    }

    private fun startFlow() {
        if (!accessibilityOn()) {
            Toast.makeText(this, "Hãy bật Trợ năng cho TikAutoTap trước", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), reqCapture)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqCapture) {
            if (resultCode == RESULT_OK && data != null) {
                val i = Intent(this, CaptureService::class.java)
                    .putExtra(CaptureService.EXTRA_CODE, resultCode)
                    .putExtra(CaptureService.EXTRA_DATA, data)
                startForegroundService(i)
                Toast.makeText(this, "Mở TikTok rồi bấm nút nổi ▶ CHƠI", Toast.LENGTH_LONG).show()
                moveTaskToBack(true)
            } else {
                Toast.makeText(this, "Bạn đã từ chối quyền quay màn hình", Toast.LENGTH_LONG).show()
            }
        }
    }
}
