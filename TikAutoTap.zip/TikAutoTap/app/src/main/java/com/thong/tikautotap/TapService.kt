package com.thong.tikautotap

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

/** Dịch vụ trợ năng: thực hiện chạm + hiển thị nút nổi điều khiển. */
class TapService : AccessibilityService() {

    companion object {
        @Volatile var instance: TapService? = null
        const val TAP_DURATION = 15L
        const val TAP_GAP = 20L
    }

    private val main = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    private var root: LinearLayout? = null
    private var label: TextView? = null
    private var params: WindowManager.LayoutParams? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        if (Bot.captureActive) showOverlay()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        hideOverlay()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        hideOverlay()
        super.onDestroy()
    }

    /** Chạm lần lượt các điểm (px màn hình). Trả về thời gian cử chỉ (ms). */
    fun tap(points: List<FloatArray>): Long {
        if (points.isEmpty()) return 0
        val builder = GestureDescription.Builder()
        var t = 0L
        for (p in points.take(4)) {
            val path = Path()
            path.moveTo(p[0], p[1])
            builder.addStroke(GestureDescription.StrokeDescription(path, t, TAP_DURATION))
            t += TAP_DURATION + TAP_GAP
        }
        val total = t
        main.post {
            try {
                dispatchGesture(builder.build(), null, null)
            } catch (_: Exception) {
            }
        }
        return total
    }

    // ---------------- Nút nổi ----------------

    fun showOverlay() {
        main.post {
            if (root != null) return@post
            val manager = wm ?: (getSystemService(WINDOW_SERVICE) as WindowManager).also { wm = it }
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION")
            manager.defaultDisplay.getRealMetrics(dm)

            val density = dm.density
            val bg = GradientDrawable().apply {
                cornerRadius = 40f * density
                setColor(Color.parseColor("#CC1B5E20"))
            }
            val tv = TextView(this).apply {
                textSize = 16f
                setTextColor(Color.WHITE)
                setPadding((16 * density).toInt(), (10 * density).toInt(), (16 * density).toInt(), (10 * density).toInt())
                gravity = Gravity.CENTER
            }
            val close = TextView(this).apply {
                text = "✕"
                textSize = 16f
                setTextColor(Color.WHITE)
                setPadding((12 * density).toInt(), (10 * density).toInt(), (14 * density).toInt(), (10 * density).toInt())
                setOnClickListener {
                    stopService(Intent(this@TapService, CaptureService::class.java))
                }
            }
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                background = bg
                addView(tv)
                addView(close)
            }
            label = tv
            root = box

            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP or Gravity.START
            lp.x = (dm.widthPixels * 0.14f).toInt()
            lp.y = (dm.heightPixels * 0.105f).toInt()
            params = lp

            // Kéo thả + bấm
            var downX = 0f
            var downY = 0f
            var startX = 0
            var startY = 0
            var moved = false
            tv.setOnTouchListener { _, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = e.rawX; downY = e.rawY
                        startX = lp.x; startY = lp.y
                        moved = false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - downX
                        val dy = e.rawY - downY
                        if (abs(dx) > 12 || abs(dy) > 12) moved = true
                        if (moved) {
                            lp.x = startX + dx.toInt()
                            lp.y = startY + dy.toInt()
                            try { manager.updateViewLayout(box, lp) } catch (_: Exception) {}
                        }
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) {
                            Bot.running = !Bot.running
                            refreshLabel()
                        }
                    }
                }
                true
            }

            try {
                manager.addView(box, lp)
            } catch (_: Exception) {
                root = null
                return@post
            }
            refreshLabel()
            main.postDelayed(ticker, 500)
        }
    }

    private val ticker = object : Runnable {
        override fun run() {
            if (root == null) return
            refreshLabel()
            main.postDelayed(this, 500)
        }
    }

    private fun refreshLabel() {
        val tv = label ?: return
        val box = root ?: return
        if (Bot.running) {
            tv.text = "■ DỪNG  ${Bot.taps}"
            (box.background as? GradientDrawable)?.setColor(Color.parseColor("#CCB71C1C"))
        } else {
            tv.text = "▶ CHƠI"
            (box.background as? GradientDrawable)?.setColor(Color.parseColor("#CC1B5E20"))
        }
    }

    fun hideOverlay() {
        main.post {
            main.removeCallbacks(ticker)
            val r = root ?: return@post
            try { wm?.removeView(r) } catch (_: Exception) {}
            root = null
            label = null
        }
    }
}
